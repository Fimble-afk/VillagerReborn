# Villager Reborn — Minecraft Forge Mod
**Version:** 1.0.0 | **Minecraft:** 1.19.2 | **Forge:** 43.3.0+

> Bring your villages to life with rich dialogue, quests, reputation ranks, daily rewards, and a living village economy.

---

## 📦 Installation

1. Install [Minecraft Forge 1.19.2](https://files.minecraftforge.net/)
2. Drop `villagerreborn-1.0.0.jar` into your `.minecraft/mods/` folder
3. Launch Minecraft with the Forge profile

---

## ⚙️ Building from Source

```bash
# Requires JDK 17 and Gradle
./gradlew build
# Output: build/libs/villagerreborn-1.0.0.jar
```

---

## 🎮 How to Play

### Talking to Villagers
Right-click any villager to start a conversation. Every interaction:
- Shows a greeting based on your **rank** with that village
- Displays **profession-specific chitchat** (farmers talk crops, librarians talk books, etc.)
- Gives a small **+1 relation point** for socializing
- May offer you a **quest**

---

## 🏆 Reputation System

Each village tracks your **relation points** separately. Points are earned by:
- Talking to villagers (+1 per conversation)
- Completing quests (+30–100 pts)
- Killing hostile mobs near the village (+3 pts per kill)

| Rank | Points Required | Perks |
|------|----------------|-------|
| 🧍 Stranger | 0 | Basic interaction, simple quests |
| 🤝 Acquaintance | 100 | Villagers recognize you, +2 daily emeralds |
| 👫 Friend | 300 | Friendly dialogue, +5 daily emeralds, village expansion begins |
| ⚔️ Ally | 700 | Full quest pool, +10 daily emeralds, village expands more |
| 👑 Champion | 1500 | 20 daily emeralds, Personal Guardian Golem, max quest rewards |

### Rank-Up Bonuses
When you rank up, you receive an **immediate emerald bonus**:
- Acquaintance: 5 emeralds
- Friend: 15 emeralds
- Ally: 30 emeralds
- Champion: 64 emeralds

---

## 📜 Quest System

Right-click a villager and they may offer you a quest. There are **20+ unique quests** across 3 categories:

### 📦 Delivery Quests
Bring specific items to the villager:
- **Daily Bread** — 8 bread
- **Lumber Supply** — 32 oak logs
- **Iron for Tools** — 8 iron ingots
- **Harvest Festival** — 6 pumpkins
- *(and more!)*

### ⚔️ Combat Quests
Slay nearby monsters threatening the village:
- **Undead Threat** — Kill 5 zombies
- **Pillager Patrol** — Dispatch 4 pillagers
- **Explosive Problem** — Eliminate 3 creepers
- **Witchcraft** — Slay 3 witches
- *(and more!)*

### 🌾 Gathering Quests
Collect raw resources for the village:
- **Glass for Windows** — 16 sand
- **Leatherwork** — 8 leather
- **Bowyer's Request** — 16 string
- *(and more!)*

Quest rewards scale with difficulty: **2–8 emeralds + 30–100 relation points**.

---

## 📒 Quest Journal

Craft a **Quest Journal** to track everything:

```
[Book] + [Feather] + [Ink Sac]
```

Right-click it to see:
- All villages you've visited with current rank and points
- Every active quest with current progress
- Daily emerald income per village

---

## 🏘️ Living Village AI

Villagers don't just stand around! They actively work:

- **Farmers** till soil, plant wheat seeds, and harvest fully grown crops
- **Masons** lay stone brick paths around the village
- **All villagers** have context-aware dialogue about their work

When you reach **Friend rank** or higher, the village **physically expands** — a new house is built near the village edge!

---

## 🗡️ Personal Guardian Golem

Reaching **Champion rank** in a village grants you a personal **Guardian Golem**:
- Named after you ("Alex's Guardian")
- Spawns near you when you're in the village
- Attacks any hostile mob that targets you
- Respawns if destroyed (on your next visit)

---

## 💰 Daily Emerald Income

Log in each Minecraft day to claim your income (once per real game-day):

| Rank | Daily Emeralds |
|------|---------------|
| Stranger | 0 |
| Acquaintance | 2 |
| Friend | 5 |
| Ally | 10 |
| Champion | 20 |

Income is paid automatically when you enter a village you have rank in.

---

## 🗺️ Village Detection

The mod identifies villages by grouping villagers within a 64-block grid. Each cluster of villagers forms its own village with its own reputation track. You can have **different ranks in different villages**!

---

## 🔧 Technical Notes

- **Forge version:** 1.19.2-43.3.0
- **Java:** 17
- **No dependencies** beyond Forge
- Data is stored in **player NBT** via Forge Capabilities — persists on death and respawn
- Kill quest progress tracked in real-time via `LivingDeathEvent`
- Village expansion triggers on rank-up (Friend or higher)

---

## 🚧 Planned Features (Future Versions)

- [ ] Custom villager GUI screen (instead of chat messages)
- [ ] Village elder NPC with special quests
- [ ] Timed quests with expiration
- [ ] Village war/raid defense events
- [ ] Player house in the village (rent system)
- [ ] Villager memory (remember player names)
- [ ] Multiplayer sync for shared village reputation
- [ ] Config file for quest rewards and rank thresholds

---

## 📄 License

MIT License — free to use, modify, and include in modpacks with credit.
